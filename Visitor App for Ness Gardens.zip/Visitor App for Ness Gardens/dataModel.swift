//
//  dataModel.swift
//  Visitor App for Ness Gardens
//
//  Created by Xiaoyi Zhang on 05/12/2023.
//

import Foundation
import MapKit

// Use [Decodable] protocol.

//MARK: plant data
struct Plant: Codable {
    var recnum: String?
    var acid: String?
    var accsta: String?
    var family: String?
    var genus: String?
    var species: String?
    var infraspecific_epithet: String?
    var vernacular_name: String?
    var cultivar_name: String?
    var donor: String?
    var latitude: Double?
    var longitude: Double?
    var country: String?
    var iso: String?
    var sgu: String?
    var loc: String?
    var alt: String?
    var cnam: String?
    var cid: String?
    var cdat: String?
    var bed: [String]
    var memoriam: String?
    var redlist: String?
    var last_modified: String?
    //thumbnails
    var images: [PlantImage]?
    //detailImage
    var detailImage : [PlantImage]?
    //collection
    var isFavourite: Bool = false //we give it a defalt value "false", which means dislike state.
    
    // Use my customized decoder to handle bed array bed[]
        private enum CodingKeys: String, CodingKey {
            case recnum, acid, accsta, family, genus, species, infraspecific_epithet, vernacular_name, cultivar_name, donor, latitude, longitude, country, iso, sgu, loc, alt, cnam, cid, cdat, bed, memoriam, redlist, last_modified, isFavourite
        }

        init(from decoder: Decoder) throws {
            let container = try decoder.container(keyedBy: CodingKeys.self)
            recnum = try container.decodeIfPresent(String.self, forKey: .recnum)
            acid = try container.decodeIfPresent(String.self, forKey: .acid)
            accsta = try container.decodeIfPresent(String.self, forKey: .accsta)
            family = try container.decodeIfPresent(String.self, forKey: .family)
            genus = try container.decodeIfPresent(String.self, forKey: .genus)
            species = try container.decodeIfPresent(String.self, forKey: .species)
            infraspecific_epithet = try container.decodeIfPresent(String.self, forKey: .infraspecific_epithet)
            vernacular_name = try container.decodeIfPresent(String.self, forKey: .vernacular_name)
            cultivar_name = try container.decodeIfPresent(String.self, forKey: .cultivar_name)
            donor = try container.decodeIfPresent(String.self, forKey: .donor)
            
            if let latitudeString = try container.decodeIfPresent(String.self, forKey: .latitude),
                       let latitudeValue = Double(latitudeString) {
                        latitude = latitudeValue
                    } else {
                        latitude = nil
                    }

                    if let longitudeString = try container.decodeIfPresent(String.self, forKey: .longitude),
                       let longitudeValue = Double(longitudeString) {
                        longitude = longitudeValue
                    } else {
                        longitude = nil
                    }
            
            country = try container.decodeIfPresent(String.self, forKey: .country)
            iso = try container.decodeIfPresent(String.self, forKey: .iso)
            sgu = try container.decodeIfPresent(String.self, forKey: .sgu)
            loc = try container.decodeIfPresent(String.self, forKey: .loc)
            alt = try container.decodeIfPresent(String.self, forKey: .alt)
            cnam = try container.decodeIfPresent(String.self, forKey: .cnam)
            cid = try container.decodeIfPresent(String.self, forKey: .cid)
            cdat = try container.decodeIfPresent(String.self, forKey: .cdat)
            
            //handle bed array. Split it by " "
            let bedString = try container.decodeIfPresent(String.self, forKey: .bed) ?? ""
            bed = bedString.components(separatedBy: .whitespaces).filter { !$0.isEmpty }
            
            memoriam = try container.decodeIfPresent(String.self, forKey: .memoriam)
            redlist = try container.decodeIfPresent(String.self, forKey: .redlist)
            last_modified = try container.decode(String.self, forKey: .last_modified)
            if let isFavouriteDecoded = try container.decodeIfPresent(Bool.self, forKey: .isFavourite) {
                isFavourite = isFavouriteDecoded
            } else {
                isFavourite = false
            }

        }
}

struct PlantData: Codable {
    var plants: [Plant]
}



//MARK: bed data
struct Bed: Codable {
    var bed_id: String
    var name: String?
    var latitude: String
    var longitude: String
    var last_modified: String
    
    //Change lat&lon to Double format
    var coordinate: CLLocationCoordinate2D? {
        guard let lat = Double(latitude), let lon = Double(longitude) else {
            print("Invalid coordinates: \(latitude), \(longitude)")
            return nil
        }
        return CLLocationCoordinate2D(latitude: lat, longitude: lon)
    }

}

struct BedData: Codable {
    var beds: [Bed]
}

//MARK: link plants and beds
struct BedSection {
    let bed: Bed
    var plants: [Plant] = []
    var distanceFromUser: CLLocationDistance = CLLocationDistanceMax
}

//MARK: thumbnail (image)
struct ImageData: Codable {
    var images: [PlantImage]
}

struct PlantImage: Codable {
    var recnum: String?
    var imgid: String?
    var img_file_name: String?
    var imgtitle: String?
    var photodt: String?
    var photonme: String?
    var copy: String?
    var last_modified: String?
    
    var thumbnailURL: URL? {
        guard let imgFileName = img_file_name else { return nil }
        return URL(string: "https://cgi.csc.liv.ac.uk/~phil/Teaching/COMP228/ness_thumbnails/\(imgFileName)")
    }
    
    var detailURL: URL? {
        guard let imgFileName = img_file_name else { return nil }
        return URL(string: "https://cgi.csc.liv.ac.uk/~phil/Teaching/COMP228/ness_images/\(imgFileName)")
    }
}

//MARK: detail image
//actual image used by DetailsViewController.swift
extension UIImageView {
    func load(url: URL) {
        DispatchQueue.global().async { [weak self] in
            if let data = try? Data(contentsOf: url) {
                if let image = UIImage(data: data) {
                    DispatchQueue.main.async {
                        self?.image = image
                    }
                }
            }
        }
    }
}

//MARK: core data
extension Plant {
    init(entity: PlantEntity) {
        self.recnum = entity.recnum
        self.acid = entity.acid
        self.accsta = entity.accsta
        self.alt = entity.alt
        //converts comma-separated strings to arrays. Then we can successfully assemble the data.
        self.bed = entity.bed?.components(separatedBy: ",") ?? []
        self.cdat = entity.cdat
        self.cid = entity.cid
        self.cnam = entity.cnam
        self.country = entity.country
        self.cultivar_name = entity.cultivar_name
        self.donor = entity.donor
        self.family = entity.family
        self.genus = entity.genus
        self.infraspecific_epithet = entity.infraspecific_epithet
        self.iso = entity.iso
        self.last_modified = entity.last_modified
        self.latitude = entity.latitude
        self.loc = entity.loc
        self.longitude = entity.longitude
        self.memoriam = entity.memoriam
        self.redlist = entity.redlist
        self.sgu = entity.sgu
        self.species = entity.species
        self.vernacular_name = entity.vernacular_name
        self.isFavourite = entity.isFavourite
    }
}
