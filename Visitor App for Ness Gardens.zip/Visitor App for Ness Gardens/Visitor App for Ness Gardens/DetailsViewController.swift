//
//  DetailsViewController.swift
//  Visitor App for Ness Gardens
//
//  Created by Xiaoyi Zhang on 07/12/2023.
//

import UIKit
import MapKit

class DetailsViewController: UIViewController {

    var plantDetails: Plant?
    
    @IBOutlet weak var detailsTextView: UITextView!
    
    @IBOutlet weak var plantMap: MKMapView!
    
    
    @IBOutlet weak var detailImageScrollView: UIScrollView!
    
    //MARK: View relevent func
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        // if we have plant'info and 'recnum'，load and show relevent images.
        if let plant = plantDetails, let recnum = plant.recnum {
            fetchAndDisplayDetailImages(for: recnum)
        }
        //text view
        if let plant = plantDetails {
            var detailsString = ""
            detailsString += "Record Number: \(plant.recnum ?? "N/A")\n"
            detailsString += "Family: \(plant.family ?? "N/A")\n"
            detailsString += "Donor: \(plant.donor ?? "N/A")\n"
            detailsString += "Country: \(plant.country ?? "N/A")\n"
            detailsString += "ISO: \(plant.iso ?? "N/A")\n"
            detailsString += "SGU: \(plant.sgu ?? "N/A")\n"
            detailsString += "Locality: \(plant.loc ?? "N/A")\n"
            detailsString += "Altitude: \(plant.alt ?? "N/A")\n"
            detailsString += "Primary Collector: \(plant.cnam ?? "N/A")\n"
            detailsString += "Collector's Identifier: \(plant.cid ?? "N/A")\n"
            detailsString += "Memoriam: \(plant.memoriam ?? "N/A")\n"
            detailsString += "Red List: \(plant.redlist ?? "N/A")\n"
            detailsString += "Last Modified: \(plant.last_modified ?? "N/A")\n"
            
            let latitudeString = plant.latitude.map { String($0) } ?? "N/A"
            let longitudeString = plant.longitude.map { String($0) } ?? "N/A"
            detailsString += "Latitude: \(latitudeString)\n"
            detailsString += "Longitude: \(longitudeString)\n"
            
            // For arrays, join elements into a string:
            if !plant.bed.isEmpty {
                detailsString += "Bed(s): \(plant.bed.joined(separator: ", "))\n"
            }
            // Set the concatenated string to the UITextView
            detailsTextView.text = detailsString
            
            // Map view setup
                if let latitude = plantDetails?.latitude, let longitude = plantDetails?.longitude {
                    let location = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
                    let annotation = MKPointAnnotation()
                    annotation.coordinate = location
                    annotation.title = plantDetails?.vernacular_name ?? "Unknown Plant"
                    plantMap.addAnnotation(annotation)
                    
                    let regionRadius: CLLocationDistance = 1000000 // Adjust as needed
                    let region = MKCoordinateRegion(center: location, latitudinalMeters: regionRadius, longitudinalMeters: regionRadius)
                    plantMap.setRegion(region, animated: true)
                } else {
                    // if lat/lon is nil, hide the map
                    plantMap.isHidden = true
                }
            //this is the error value we set before, which is (0, 0). In this case, we hide the map.
            if plantDetails?.latitude == 0 && plantDetails?.longitude == 0 {
                plantMap.isHidden = true
            }
            }
        }
    //MARK: Detail images func
    // show the detail images
    func fetchAndDisplayDetailImages(for recnum: String) {
        guard let url = URL(string: "https://cgi.csc.liv.ac.uk/~phil/Teaching/COMP228/ness/data.php?class=images&recnum=\(recnum)") else {
            print("Invalid URL for detail images")
            return
        }
        let task = URLSession.shared.dataTask(with: url) { [weak self] data, response, error in
            guard let data = data, error == nil else {
                print("Error fetching detail images: \(error?.localizedDescription ?? "Unknown error")")
                return
            }
            do {
                // decode image data
                let imageData = try JSONDecoder().decode(ImageData.self, from: data)
                let images = imageData.images
                
                // make sure we have at least one image.
                if !images.isEmpty {
                    DispatchQueue.main.async {
                        self?.displayDetailImages(images)
                    }
                }
            } catch {
                print("Error parsing detail images data: \(error.localizedDescription)")
            }
        }
        task.resume()
    }
    
    // show the detail images
    func displayDetailImages(_ images: [PlantImage]) {
        for (index, image) in images.enumerated() {
            if let detailURL = image.detailURL {
                // add UIImageView
                let imageView = UIImageView()
                imageView.contentMode = .scaleAspectFit
                
                // use additional func to load images
                imageView.load(url: detailURL)
                
                // set imageView's frame
                let xPosition = self.detailImageScrollView.frame.width * CGFloat(index)
                imageView.frame = CGRect(x: xPosition, y: 0, width: self.detailImageScrollView.frame.width, height: self.detailImageScrollView.frame.height)
                
                // add imageView to scrollView
                detailImageScrollView.contentSize.width = detailImageScrollView.frame.width * CGFloat(index + 1)
                detailImageScrollView.addSubview(imageView)
            }
        }
    }
    }
