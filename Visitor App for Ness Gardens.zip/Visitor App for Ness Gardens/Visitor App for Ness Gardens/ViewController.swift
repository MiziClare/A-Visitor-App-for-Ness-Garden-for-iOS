//
//  ViewController.swift
//  Visitor App for Ness Gardens
//
//  Created by Xiaoyi Zhang on 02/12/2023.
//
//MARK: Distance sorting is updated every 3 meters of user movement.
import UIKit
import MapKit
import CoreLocation
import CoreData

class ViewController: UIViewController, UITableViewDataSource, UITableViewDelegate, MKMapViewDelegate, CLLocationManagerDelegate {
    
    //last location of user
    var lastLocationUpdate: CLLocation?
    // global array
    var globalPlantsArray: [Plant] = []
    var globalBedsArray: [Bed] = []
    var bedSections: [BedSection] = []
    var globalImagesArray: [PlantImage] = []
    
    //MARK: Fetching data (plants & beds)
    
    //fetch plant data from JSON format
    func fetchAndStorePlantsData() {
        let localPlants = fetchPlantsFromCoreData()
        if localPlants.isEmpty {
            // No local data, fetch from URL
            guard let url = URL(string: "https://cgi.csc.liv.ac.uk/~phil/Teaching/COMP228/ness/data.php?class=plants") else {
                print("Invalid URL")
                return
            }
            let task = URLSession.shared.dataTask(with: url) { data, response, error in
                guard let data = data, error == nil else {
                    print("Error fetching PLANT data: \(error?.localizedDescription ?? "Unknown error")")
                    return
                }
                do {
                    let decodedData = try JSONDecoder().decode(PlantData.self, from: data)
                    DispatchQueue.main.async {
                        self.globalPlantsArray = decodedData.plants.filter { $0.accsta == "C" }
                        self.savePlantsToCoreData(self.globalPlantsArray)
                        self.myTable.reloadData()
                    }
                } catch {
                    print("Error parsing PLANT data: \(error.localizedDescription)")
                }
            }
            task.resume()
            print("【we fetch plant data from URL】")
        } else {
            // Local data exists, use it
            DispatchQueue.main.async {
                self.globalPlantsArray = localPlants
                self.myTable.reloadData()
            }
            print("【we fetch plant data from CORE DATA】")
        }
    }

    //fetch bed data from JSON format
    func fetchAndStoreBedsData() {
        guard let url = URL(string: "https://cgi.csc.liv.ac.uk/~phil/Teaching/COMP228/ness/data.php?class=beds") else {
            print("Invalid URL")
            return
        }
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            guard error == nil else {
                    print("bed Networking error: \(error!.localizedDescription)")
                    return
                }
                guard let data = data else {
                    print("No bed data received")
                    return
                }
            do {
                let decodedData = try JSONDecoder().decode(BedData.self, from: data)
                self.globalBedsArray = decodedData.beds
                print("Beds data successfully fetched and stored.")
                
                //update pings on map
                DispatchQueue.main.async {
                        self.updateMapAnnotations()
                    }
            } catch {
                print(">>>>>>>>  Failed to decode bed data: \(error.localizedDescription)")
            }
        }
        
        task.resume()
    }
    
    //MARK: Updating (table & map)
    //update anntations on map
    func updateMapAnnotations() {
        // move annotation before adding
        myMap.removeAnnotations(myMap.annotations)

        // check if globalBedsArray has data
        print("Updating map annotations for \(globalBedsArray.count) beds")

        for bed in globalBedsArray {
            if let coordinate = bed.coordinate {
                let annotation = MKPointAnnotation()
                annotation.title = bed.name
                annotation.subtitle = bed.bed_id
                annotation.coordinate = coordinate
                myMap.addAnnotation(annotation)
            } else {
                print("Invalid coordinates for bed: \(bed.bed_id)")
            }
        }
    }
//update table
    func updateTableData(userLocation: CLLocation) {
        // use asyc to solve, avoiding block main thread.
        DispatchQueue.global(qos: .userInteractive).async { [weak self] in
                guard let self = self else { return }
                // use global array to creat bedSections
                var newBedSections = self.globalBedsArray.map { BedSection(bed: $0) }
                // calculate distance between bed and user, and flit the relevent plants in their beds
                for (index, bedSection) in newBedSections.enumerated() {
                    if let bedLocation = bedSection.bed.coordinate {
                        let bedCLLocation = CLLocation(latitude: bedLocation.latitude, longitude: bedLocation.longitude)
                        newBedSections[index].distanceFromUser = userLocation.distance(from: bedCLLocation)
                    }
                    newBedSections[index].plants = self.globalPlantsArray.filter { plant in
                        plant.bed.contains(where: { $0 == bedSection.bed.bed_id })
                    }
                }
                // sort by ditance from user
                newBedSections.sort { $0.distanceFromUser < $1.distanceFromUser }
            
                // updat UI in main thread
                   DispatchQueue.main.async {
                       self.bedSections = newBedSections
                       self.myTable.reloadData()
                   }
               }
           }

    // MARK: Map & Location related stuff
    @IBOutlet weak var myMap: MKMapView!
    
    var locationManager = CLLocationManager()
    var firstRun = true
    var startTrackingTheUser = false
    
    //NOTE: when the user moves more than 3 meters, update data.
    func locationManager(_ manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        guard let locationOfUser = locations.last else { return }
                
        // Check if we have a last known location
        if let lastLocation = lastLocationUpdate {
            let distance = locationOfUser.distance(from: lastLocation)
            // Check if the distance is greater than or equal to 5 meters
            if distance >= 5 {
                // Update the last known location
                lastLocationUpdate = locationOfUser
                // Update table data since the user has moved 5 meters or more
                updateTableData(userLocation: locationOfUser)
            }
            } else {
                // This is the first update, so save the user's current location
                lastLocationUpdate = locationOfUser
                // Update the table data for the first time
                updateTableData(userLocation: locationOfUser)
            }
        //let locationOfUser = locations[0]
        
        //NOTE: update table data whenever user's location changes
        updateTableData(userLocation: locationOfUser)
        
        let latitude = locationOfUser.coordinate.latitude
        let longitude = locationOfUser.coordinate.longitude
        
        //get user's location
        let location = CLLocationCoordinate2D(latitude: latitude, longitude: longitude)
        
        if firstRun {
            firstRun = false
            
            let latDelta: CLLocationDegrees = 0.0025
            let lonDelta: CLLocationDegrees = 0.0025
            
            //a span defines how large an area is depicted on the map.
            let span = MKCoordinateSpan(latitudeDelta: latDelta, longitudeDelta: lonDelta)
            
            //a region defines a centre and a size of area covered.
            let region = MKCoordinateRegion(center: location, span: span)
            
            //make the map show that region we just defined
            self.myMap.setRegion(region, animated: true)
            
            //set a timer to set our boolean to "true" in 5s
            _ = Timer.scheduledTimer(timeInterval: 5.0, target: self, selector: #selector(startUserTracking), userInfo: nil, repeats: false)
        }
        if startTrackingTheUser == true {
            myMap.setCenter(location, animated: true)
        }
    }
    
    @objc func startUserTracking() {
        startTrackingTheUser = true
    }
    
    func locationManager(_ manager: CLLocationManager, didFailWithError error: Error) {
        print("Location manager failed with error: \(error.localizedDescription)")
    }

    // MARK: Table related stuff
    
    @IBOutlet weak var myTable: UITableView!
    
    //table sections
    func numberOfSections(in tableView: UITableView) -> Int {
        return bedSections.count
    }
    
    //number of rows in section
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return bedSections[section].plants.count
    }
    
    //section names
    func tableView(_ tableView: UITableView, titleForHeaderInSection section: Int) -> String? {
        return bedSections[section].bed.name
        //return "testing"
    }
    
    //cell height
    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 200
    }
    // 在 ViewController.swift
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = tableView.dequeueReusableCell(withIdentifier: "PlantTableViewCell") as! PlantTableViewCell
        
        print(bedSections[indexPath.section].plants[indexPath.row].images ?? "")
            var plant = bedSections[indexPath.section].plants[indexPath.row]
            plant.images = globalImagesArray.filter { $0.recnum == plant.recnum }
            cell.configure(with: plant)

        //for collection
        cell.configure(with: plant)
        cell.delegate = self
        cell.updateFavoriteButton(isFavorite: plant.isFavourite)
        
            return cell
    }

    //MARK: Thumbnails
    
    //TODO: cannot run this func
    func fetchAndStoreImagesData() {
        guard let url = URL(string: "https://cgi.csc.liv.ac.uk/~phil/Teaching/COMP228/ness/data.php?class=images") else {
            print("Invalid URL for images")
            return
        }
        
        let task = URLSession.shared.dataTask(with: url) { data, response, error in
            // Check for network errors
            guard let data = data, error == nil else {
                print("Error fetching IMAGES data: \(error?.localizedDescription ?? "Unknown error")")
                return
            }

            do {
                // Attempt to decode the JSON data
                let decodedData = try JSONDecoder().decode(ImageData.self, from: data)
                
                // Check if the decoding was successful
                self.globalImagesArray = decodedData.images
                
                print("Images data successfully fetched and stored.")
                
                DispatchQueue.main.async {
                    self.myTable.reloadData()
                }
            } catch {
                // Print the error details if decoding fails
                print("Error parsing IMAGES data: \(error.localizedDescription)")
                print("JSON data:", String(data: data, encoding: .utf8) ?? "Unable to convert to string")
            }
        }
        
        task.resume()
    }
    
    //link thumbnails to plants
    func linkImagesToPlants() {
        
        for index in 0..<globalPlantsArray.count {
            let plant = globalPlantsArray[index]
            globalPlantsArray[index].images = globalImagesArray.filter { $0.recnum == plant.recnum }
        }
        print("Linking images to plants")
    }

        //MARK: View related stuff
        
        override func viewDidLoad() {
            super.viewDidLoad()
            // Do any additional setup after loading the view.
            myTable.delegate = self
            myTable.dataSource = self
            //Make this view controller a delegate of the Location Manager, so that it
            //is able to call functions provided in this view controller.
            locationManager.delegate = self as CLLocationManagerDelegate
            
            //set the level of accuracy for the user's location.
            locationManager.desiredAccuracy = kCLLocationAccuracyBestForNavigation
            
            locationManager.distanceFilter = 3//when distance >= 3, update
            //Ask the location manager to request authorisation from the user. Note that this
            //only happens once if the user selects the "when in use" option. If the user
            //denies access, then your app will not be provided with details of the user's
            //location.
            locationManager.requestWhenInUseAuthorization()
            
            //Once the user's location is being provided then ask for updates when the user
            //moves around.
            locationManager.startUpdatingLocation()
            
            //configure the map to show the user's location (with a blue dot).
            myMap.showsUserLocation = true
            
            //reload map
            fetchAndStoreBedsData()
            fetchAndStorePlantsData()
            
            fetchAndStoreImagesData()
            myMap.reloadInputViews()
            myTable.reloadData()
        }
    //when users click a certain cell
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
        performSegue(withIdentifier: "toDetail", sender: nil)
    }
    //for segues: unwind & pass data to DetailsViewController.swift
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "toDetail" {
            if let detailVC = segue.destination as? DetailsViewController,
               let indexPath = myTable.indexPathForSelectedRow {
                       
                    let selectedPlant = bedSections[indexPath.section].plants[indexPath.row]
                    detailVC.plantDetails = selectedPlant
            }
        }
    }
    
    //MARK: Core data
    //store plant data into core data entity "PlantEntity"
    func savePlantsToCoreData(_ plants: [Plant]) {
        
        print("starting core data for plants")
        
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        
        for plant in plants {
            let plantEntity = PlantEntity(context: context)
            plantEntity.recnum = plant.recnum
                    plantEntity.acid = plant.acid
                    plantEntity.accsta = plant.accsta
                    plantEntity.alt = plant.alt
                    plantEntity.bed = plant.bed.joined(separator: ",") // if bed is a string array
                    plantEntity.cdat = plant.cdat
                    plantEntity.cid = plant.cid
                    plantEntity.cnam = plant.cnam
                    plantEntity.country = plant.country
                    plantEntity.cultivar_name = plant.cultivar_name
                    plantEntity.donor = plant.donor
                    plantEntity.family = plant.family
                    plantEntity.genus = plant.genus
                    plantEntity.infraspecific_epithet = plant.infraspecific_epithet
                    plantEntity.iso = plant.iso
                    plantEntity.last_modified = plant.last_modified
            //As let & lon are "Double?" type
            //so we set a false coordinate value (0, 0).
            //afterwards, we let map be hidden if a plant's coordinate is (0, 0) in DetailsViewController.swift
            
                    plantEntity.latitude = plant.latitude ?? 0
                    plantEntity.longitude = plant.longitude ?? 0
            
                    plantEntity.loc = plant.loc
                    plantEntity.memoriam = plant.memoriam
                    plantEntity.redlist = plant.redlist
                    plantEntity.sgu = plant.sgu
                    plantEntity.species = plant.species
                    plantEntity.vernacular_name = plant.vernacular_name
            
            plantEntity.isFavourite = plant.isFavourite
        }
        
        do {
            try context.save()
        } catch {
            print("Failed to save plants: \(error.localizedDescription)")
        }
        print("Store plants in core data")
    }
    
    //fetch plant data from core data, using our own metho, which has been created in dataModel.swift
    func fetchPlantsFromCoreData() -> [Plant] {
        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        let fetchRequest = NSFetchRequest<PlantEntity>(entityName: "PlantEntity")

        do {
            let plantEntities = try context.fetch(fetchRequest)
            return plantEntities.map { Plant(entity: $0) }
        } catch {
            print("Failed to fetch plants: \(error.localizedDescription)")
            return []
        }
    }
    //MARK: Collection button
    
    //for users to set or cancel a "favourite plant" called [toggle]
    func toggleFavoriteStatus(for plant: Plant) -> Plant {
        var updatedPlant = plant
        updatedPlant.isFavourite.toggle()

        let context = (UIApplication.shared.delegate as! AppDelegate).persistentContainer.viewContext
        let fetchRequest: NSFetchRequest<PlantEntity> = PlantEntity.fetchRequest()
        fetchRequest.predicate = NSPredicate(format: "recnum == %@", updatedPlant.recnum!)

        do {
            let results = try context.fetch(fetchRequest)
            if let plantEntity = results.first {
                plantEntity.isFavourite = updatedPlant.isFavourite
                try context.save()
            }
        } catch {
            print("Failed to fetch or save plant: \(error.localizedDescription)")
        }
        // update globalPlantsArray
            if let index = globalPlantsArray.firstIndex(where: { $0.recnum == updatedPlant.recnum }) {
                globalPlantsArray[index] = updatedPlant
            }
        return updatedPlant
    }

    } //class ending brace

//extension -- pass messages between ViewController.swift & PlantTableViewCell.swift, which is my own cell type. We use it to synchronize state in these two fils.
extension ViewController: PlantTableViewCellDelegate {
    func didTapFavoriteButton(on cell: PlantTableViewCell) {
        guard let indexPath = myTable.indexPath(for: cell) else { return }
        
        var plant = bedSections[indexPath.section].plants[indexPath.row]
        plant = toggleFavoriteStatus(for: plant)
        bedSections[indexPath.section].plants[indexPath.row] = plant
        cell.updateFavoriteButton(isFavorite: plant.isFavourite)
    }
}

