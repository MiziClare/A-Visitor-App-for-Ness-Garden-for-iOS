//
//  PlantTableViewCell.swift
//  Visitor App for Ness Gardens
//
//  Created by Xiaoyi Zhang on 07/12/2023.
//
//MARK: My customized cell
import Foundation
import UIKit

//for delegate
protocol PlantTableViewCellDelegate: AnyObject {
    func didTapFavoriteButton(on cell: PlantTableViewCell)
}

//cell func includes UILabel, UIImageView, and UIButton
class PlantTableViewCell: UITableViewCell {
    weak var delegate: PlantTableViewCellDelegate?
    
    @IBOutlet weak var genusLabel: UILabel!
    @IBOutlet weak var speciesLabel: UILabel!
    @IBOutlet weak var infraspecificEpithetLabel: UILabel!
    @IBOutlet weak var vernacularNameLabel: UILabel!
    @IBOutlet weak var cultivarNameLabel: UILabel!
    
    @IBOutlet weak var thumbnailImageView: UIImageView!
    
    @IBOutlet weak var favoriteButton: UIButton!
    
    var plant: Plant?
    
    func configure(with plant: Plant) {
        self.plant = plant
        genusLabel.text = "Genus: \(plant.genus ?? "-")"
        speciesLabel.text = "Species: \(plant.species ?? "-")"
        infraspecificEpithetLabel.text = "Infraspecific Epithet: \(plant.infraspecific_epithet ?? "-")"
        vernacularNameLabel.text = "Vernacular Name: \(plant.vernacular_name ?? "-")"
        cultivarNameLabel.text = "Cultivar Name: \(plant.cultivar_name ?? "-")"
        
        // Set a thumbnail or clear the image view if there are no images
        if let firstImage = plant.images?.first, let url = firstImage.thumbnailURL {
            loadImage(from: url, for: plant) { image in
                DispatchQueue.main.async {
                    // Ensure the UI updates are on the main thread
                    self.thumbnailImageView.image = image
                    self.setNeedsLayout()
                }
            }
        } else {
            // Clear the image view if there are no thumbnails
            DispatchQueue.main.async {
                self.thumbnailImageView.image = nil
            }
        }
        // make sure collction state shows correctly.
        updateFavoriteButton(isFavorite: plant.isFavourite)
        }
    
    private func loadImage(from url: URL, for plant: Plant, completion: @escaping (UIImage?) -> Void) {
        URLSession.shared.dataTask(with: url) { [weak self] data, response, error in
            if let error = error {
                // print error logs
                print("Image download failed with error: \(error.localizedDescription)")
                DispatchQueue.main.async {
                    completion(nil)
                }
                return
            }

            guard let data = data else {
                // if no data
                print("No data received for image download")
                DispatchQueue.main.async {
                    completion(nil)
                }
                return
            }

            // try to create a UIImage
            if let image = UIImage(data: data) {
                // if image loads successfully
                print("Image downloaded successfully for plant: \(plant.recnum ?? "")")
                DispatchQueue.main.async {
                    // make sure the current cell shows the correct text data when loading a thumbnail.
                    if self?.plant?.recnum == plant.recnum {
                        self?.thumbnailImageView.image = image
                        completion(image)
                    }
                }
            } else {
                // if cannot creat a UIImage
                print("Data could not be converted to an image")
                DispatchQueue.main.async {
                    completion(nil)
                }
            }
        }.resume()
    }
    //func for preparing cell in case of misdisplay when reloading cells.
    override func prepareForReuse() {
        super.prepareForReuse()
        // Clear the image and other content
        thumbnailImageView.image = nil
        genusLabel.text = nil
        speciesLabel.text = nil
        infraspecificEpithetLabel.text = nil
        vernacularNameLabel.text = nil
        cultivarNameLabel.text = nil
    }
    
    //MARK: Collection button
    
    //set a special format
    func updateFavoriteButton(isFavorite: Bool) {
        let buttonTitle = isFavorite ? "♥️" : "🤍"
        favoriteButton.setTitle(buttonTitle, for: .normal)
        favoriteButton.tintColor = isFavorite ? .red : .gray
    }
    //when users click the favourite button...
    @IBAction func favoriteButtonTapped(_ sender: UIButton) {
        delegate?.didTapFavoriteButton(on: self)
    }
    
}


